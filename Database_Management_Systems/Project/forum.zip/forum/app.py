from flask import Flask, request, jsonify
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
api = Api(app)
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql://root:@localhost/forum"
db = SQLAlchemy(app)


class Topic(db.Model):

    tid = db.Column(db.Integer, primary_key=True)
    topic = db.Column(db.String)
    pid = db.Column(db.Integer)

    def save(self):
        db.session.add(self)
        db.session.commit()

    @classmethod
    def all_topics(cls):
        topics = cls.query.all()
        return jsonify([{"tid": t.tid, "topic": t.topic}
                         for t in topics])


class TopicResource(Resource):
    def get(self):
        return Topic.all_topics()


api.add_resource(TopicResource, '/topics')

if __name__ == '__main__':
    app.run(debug=True, port=8888)
