from sqlalchemy import *


db = create_engine("mysql://root:@localhost/forum")


class Topic(db.Model):

    tid = db.Column(db.Integer, primary_key=True)
    topic = db.Column(db.String)
    pid = db.Column(db.Integer)



